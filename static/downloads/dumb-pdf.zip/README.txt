
   =========================================
  |                                         |
  |    KOSMORRO DUMP PDF GENERATION TEST    |
  |                                         |
   =========================================


This package contains the minimal files necessary to test the PDF generation
like it was made by Kosmorro.

The differencies with the real generator are:
 - data are not calculated
 - Kosmorro's logo is not included (replaced with a placeholder)

To test that the PDF file is well generated, invoke the following command:

pdflatex dumb.tex

If the generation goes well, then a new file named "dumb.pdf" should have been
generated.

